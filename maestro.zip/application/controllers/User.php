<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }
    public function index()
    {
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['title'] = 'Profile saya';

        $this->load->view('template_user/header', $data);
        $this->load->view('user/index', $data);
        $this->load->view('template_user/footer', $data);
    }

    public function edit()
    {
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['title'] = 'Edit Profile';

        $this->form_validation->set_rules('name', 'Nama Lengkap', 'required|trim', ['required' => 'Nama Wajib di isi']);

        if ($this->form_validation->run() == false) {
            $this->load->view('template_user/header', $data);
            $this->load->view('user/edit', $data);
            $this->load->view('template_user/footer', $data);
        } else {
            $name = $this->input->post('name');
            $email = $this->input->post('email');

            // Cek apabila ada gambar yang akan di upload

            $upload_image = $_FILES['image']['name'];

            if ($upload_image) {
                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size']     = '2048';
                $config['upload_path'] = './assets/img/profile';

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('image')) {
                    $old_image = $data['user']['image'];
                    if ($old_image != 'default.jpg') {
                        unlink('http://localhost/kerja_praktek/assets/img/profile' . $old_image);
                    }

                    $new_image = $this->upload->data('file_name');
                    $this->db->set('image', $new_image);
                } else {
                    echo $this->upload->display_errors();
                }
            }

            $this->db->set('name', $name);
            $this->db->where('email', $email);
            $this->db->update('user');

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert" >Profile berhasil di edit</div>');
            redirect('user');
        }
    }

    public function changePassword()
    {
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['title'] = 'Ganti Password';

        $this->form_validation->set_rules('current_password', 'Current Password', 'required|trim', ['required' => 'Wajib di isi']);
        $this->form_validation->set_rules(
            'new_password1',
            'Konfirmasi New Password',
            'required|trim|min_length[3]|matches[new_password2]',
            [
                'required' => 'Wajib di isi',
                'min_length' => 'Password minimal 3 karakter',
                'matches' => 'Password harus sama'
            ]
        );
        $this->form_validation->set_rules(
            'new_password2',
            'Konfirmasi New Password',
            'required|trim|min_length[3]|matches[new_password1]',
            [
                'required' => 'Wajib di isi',
                'min_length' => 'Password minimal 3 karakter',
                'matches' => 'Password harus sama'
            ]
        );

        if ($this->form_validation->run() == false) {
            $this->load->view('template_user/header', $data);
            $this->load->view('user/changepassword', $data);
            $this->load->view('template_user/footer', $data);
        } else {
            $current_password = $this->input->post('current_password');
            $new_password = $this->input->post('new_password1');

            if (!password_verify($current_password, $data['user']['password'])) {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert" >Password lama salah</div>');
                redirect('user/changepassword');
            } else {
                if ($current_password == $new_password) {
                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert" >Password lama dan baru tidak boleh sama</div>');
                    redirect('user/changepassword');
                } else {
                    // jika password sudah benar
                    $password_hash = password_hash('$new_password', PASSWORD_DEFAULT);

                    $this->db->set('password', $password_hash);
                    $this->db->where('email', $this->session->userdata('email'));
                    $this->db->update('user');

                    $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert" >Password berhasil di ubah</div>');
                    redirect('user/changepassword');
                }
            }
        }
    }

    // Maestro Sport Academi

    // Registrasi Pelatih
    public function dataPelatih()
    {
        $data['title'] = 'Pelatih';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['pelatih'] = $this->db->get('data_pelatih')->result_array();

        $this->load->view('user/pelatih', $data);
    }

    public function detailPelatih()
    {
        $data['title'] = 'Detail Pelatih';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();


        $this->load->view('user/detail_pelatih', $data);
    }

    // Halaman user
    public function home()
    {
        $data['title'] = 'Halaman Catalog';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['catalog'] = $this->db->get('catalog_jakarta')->result_array();
        $data['catalogbandung'] = $this->db->get('catalog_bandung')->result_array();

        $this->load->view('template_user/header', $data);
        $this->load->view('user/home', $data);
        $this->load->view('template_user/footer', $data);
    }

    // Catalog Jakarta
    public function detailCatalogPrivateJakarta()
    {
        $data['title'] = 'Detail Catalog';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['detailcatalog'] = $this->db->get_where('catalog_jakarta')->row_array();
        // $data['detailcatalogbandung'] = $this->db->get_where('catalog_bandung', ['id' => $id])->row_array();

        $this->load->view('template_user/header', $data);
        $this->load->view('user/detail_catalog', $data);
        $this->load->view('template_user/footer', $data);
    }

    public function detailCatalogKelasJakarta()
    {
        $data['title'] = 'Detail Catalog';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['detailcatalog'] = $this->db->get_where('catalog_jakarta')->row_array();
        // $data['detailcatalogbandung'] = $this->db->get_where('catalog_bandung', ['id' => $id])->row_array();

        $this->load->view('template_user/header', $data);
        $this->load->view('user/detail_kelas_jakarta', $data);
        $this->load->view('template_user/footer', $data);
    }

    public function detailCatalogTerapiJakarta()
    {
        $data['title'] = 'Detail Catalog';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['detailcatalog'] = $this->db->get_where('catalog_jakarta')->row_array();
        // $data['detailcatalogbandung'] = $this->db->get_where('catalog_bandung', ['id' => $id])->row_array();

        $this->load->view('template_user/header', $data);
        $this->load->view('user/detail_terapi_jakarta', $data);
        $this->load->view('template_user/footer', $data);
    }

    // Catalog Bandung
    public function detailCatalogbandung($id)
    {
        $data['title'] = 'Detail Catalog';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['detailcatalogbandung'] = $this->db->get_where('catalog_bandung', ['id' => $id])->row_array();

        $this->load->view('template_user/header', $data);
        $this->load->view('user/detail_catalog_bandung', $data);
        $this->load->view('template_user/footer', $data);
    }

    public function orderBandung($id)
    {
        $data['title'] = 'Form Order Bandung';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['detailcatalogbandung'] = $this->db->get_where('catalog_bandung', ['id' => $id])->row_array();

        $this->load->view('template_user/header', $data);
        $this->load->view('user/form_order_bandung', $data);
        $this->load->view('template_user/footer', $data);
    }

    public function jumlahSiswa()
    {
        $data['title'] = 'Pilih paket';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('jumlah_siswa', 'Jumlah Siswa', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('template_user/header', $data);
            $this->load->view('user/jumlah_siswa', $data);
            $this->load->view('template_user/footer', $data);
        } else {
            $this->_jumlah();
        }
    }

    private function _jumlah()
    {

        $jumlah = $this->input->post('jumlah_siswa');

        if ($jumlah == 1) {
            redirect('user/order');
        }
        if ($jumlah == 2) {
            redirect('user/order2');
        }
        if ($jumlah == 3) {
            redirect('user/order3');
        }
        if ($jumlah == 4) {
            redirect('user/order4');
        }
    }


    public function order()
    {
        $data['orderjakarta'] = $this->db->get('order_jakarta')->result_array();
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        // $data['detailcatalog'] = $this->db->get_where('catalog_jakarta', ['id' => $id])->row_array();

        $this->form_validation->set_rules('name_siswa', 'Nama Siswa', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('nama_ortu', 'Nama ortu', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('jk', 'Jenis Kelamin', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('usia', 'Usia', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('nama_sekolah', 'Nama Sekolah', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('telepon', 'Telepon', 'required|numeric', [
            'required' => 'Form ini Wajib di isi',
            'numeric' => 'isi dengan nomor'
        ]);
        $this->form_validation->set_rules('alamat_tinggal', 'Alamat Tinggal', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('kolam', 'Kolam', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('kelas', 'kelas', 'required', ['required' => 'Form ini Wajib di isi']);

        if ($this->form_validation->run() == false) {
            $data['title'] = 'Form Order Jabodetabek';
            $this->load->view('template_user/header', $data);
            $this->load->view('user/form_order', $data);
            $this->load->view('template_user/footer', $data);
        } else {
            $this->load->model('Order_model');
            $this->Order_model->OrderSwimJakarta();
            redirect('user/cart');
        }
    }

    public function order2()
    {
        $data['orderjakarta'] = $this->db->get('order_jakarta')->result_array();
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        // $data['detailcatalog'] = $this->db->get_where('catalog_jakarta', ['id' => $id])->row_array();

        $this->form_validation->set_rules('name_siswa', 'Nama Siswa', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('nama_ortu', 'Nama ortu', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('jk', 'Jenis Kelamin', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('usia', 'Usia', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('nama_sekolah', 'Nama Sekolah', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('telepon', 'Telepon', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('alamat_tinggal', 'Alamat Tinggal', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('kolam', 'Kolam', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('kelas', 'kelas', 'required', ['required' => 'Form ini Wajib di isi']);

        $this->form_validation->set_rules('name_siswa1', 'Nama Siswa1', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('nama_ortu1', 'Nama ortu1', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('jk1', 'Jenis Kelamin1', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('usia1', 'Usia', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('nama_sekolah1', 'Nama Sekolah', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('telepon1', 'Telepon', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('alamat_tinggal1', 'Alamat Tinggal', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('kolam1', 'Kolam', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('kelas1', 'kelas', 'required', ['required' => 'Form ini Wajib di isi']);

        if ($this->form_validation->run() == false) {
            $data['title'] = 'Form Order Jabodetabek';
            $this->load->view('template_user/header', $data);
            $this->load->view('user/form_order/order2', $data);
            $this->load->view('template_user/footer', $data);
        } else {
            $this->load->model('Order_model');
            $this->Order_model->OrderSwimJakarta02();
            redirect('user/cart');
        }
    }

    public function order3()
    {
        $data['orderjakarta'] = $this->db->get('order_jakarta')->result_array();
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('name_siswa', 'Nama Siswa', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('nama_ortu', 'Nama ortu', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('jk', 'Jenis Kelamin', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('usia', 'Usia', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('nama_sekolah', 'Nama Sekolah', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('telepon', 'Telepon', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('alamat_tinggal', 'Alamat Tinggal', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('kolam', 'Kolam', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('kelas', 'kelas', 'required', ['required' => 'Form ini Wajib di isi']);

        $this->form_validation->set_rules('name_siswa1', 'Nama Siswa', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('nama_ortu1', 'Nama ortu', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('jk1', 'Jenis Kelamin', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('usia1', 'Usia', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('nama_sekolah1', 'Nama Sekolah', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('telepon1', 'Telepon', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('alamat_tinggal1', 'Alamat Tinggal', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('kolam1', 'Kolam', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('kelas1', 'kelas', 'required', ['required' => 'Form ini Wajib di isi']);

        $this->form_validation->set_rules('name_siswa2', 'Nama Siswa', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('nama_ortu2', 'Nama ortu', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('jk2', 'Jenis Kelamin', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('usia2', 'Usia', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('nama_sekolah2', 'Nama Sekolah', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('telepon2', 'Telepon', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('alamat_tinggal2', 'Alamat Tinggal', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('kolam2', 'Kolam', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('kelas2', 'kelas', 'required', ['required' => 'Form ini Wajib di isi']);

        if ($this->form_validation->run() == false) {
            $data['title'] = 'Form Order Jabodetabek';
            $this->load->view('template_user/header', $data);
            $this->load->view('user/form_order/order3', $data);
            $this->load->view('template_user/footer', $data);
        } else {
            $this->load->model('Order_model');
            $this->Order_model->OrderJakarta03();
            redirect('user/cart');
        }
    }

    public function order4()
    {
        $data['orderjakarta'] = $this->db->get('order_jakarta')->result_array();
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('name_siswa', 'Nama Siswa', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('nama_ortu', 'Nama ortu', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('jk', 'Jenis Kelamin', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('usia', 'Usia', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('nama_sekolah', 'Nama Sekolah', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('telepon', 'Telepon', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('alamat_tinggal', 'Alamat Tinggal', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('kolam', 'Kolam', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('kelas', 'kelas', 'required', ['required' => 'Form ini Wajib di isi']);

        $this->form_validation->set_rules('name_siswa1', 'Nama Siswa', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('nama_ortu1', 'Nama ortu', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('jk1', 'Jenis Kelamin', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('usia1', 'Usia', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('nama_sekolah1', 'Nama Sekolah', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('telepon1', 'Telepon', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('alamat_tinggal1', 'Alamat Tinggal', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('kolam1', 'Kolam', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('kelas1', 'kelas', 'required', ['required' => 'Form ini Wajib di isi']);

        $this->form_validation->set_rules('name_siswa2', 'Nama Siswa', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('nama_ortu2', 'Nama ortu', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('jk2', 'Jenis Kelamin', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('usia2', 'Usia', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('nama_sekolah2', 'Nama Sekolah', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('telepon2', 'Telepon', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('alamat_tinggal2', 'Alamat Tinggal', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('kolam2', 'Kolam', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('kelas2', 'kelas', 'required', ['required' => 'Form ini Wajib di isi']);

        $this->form_validation->set_rules('name_siswa3', 'Nama Siswa', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('nama_ortu3', 'Nama ortu', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('jk3', 'Jenis Kelamin', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('usia3', 'Usia', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('nama_sekolah3', 'Nama Sekolah', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('telepon3', 'Telepon', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('alamat_tinggal3', 'Alamat Tinggal', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('kolam3', 'Kolam', 'required', ['required' => 'Form ini Wajib di isi']);
        $this->form_validation->set_rules('kelas3', 'kelas', 'required', ['required' => 'Form ini Wajib di isi']);

        if ($this->form_validation->run() == false) {
            $data['title'] = 'Form Order Jabodetabek';
            $this->load->view('template_user/header', $data);
            $this->load->view('user/form_order/order4', $data);
            $this->load->view('template_user/footer', $data);
        } else {
            $this->load->model('Order_model');
            $this->Order_model->OrderJakarta04();
            redirect('user/cart');
        }
    }


    public function cart()
    {
        $data['title'] = 'Halama Cart';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->load->view('user/cart', $data);
    }

    public function profil()
    {
        $this->load->view('user/profil');
    }
}
