<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }
    public function index()
    {
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['title'] = 'Dashboard';
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/index', $data);
        $this->load->view('templates/footer', $data);
    }

    public function role()
    {
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['rol'] = $this->db->get('user_rol')->result_array();

        $data['title'] = 'User Role';
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/role', $data);
        $this->load->view('templates/footer', $data);
    }

    public function roleAccess($rol_id)
    {
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['rol'] = $this->db->get_where('user_rol', ['id' => $rol_id])->row_array();
        $this->db->where('id !=', 1);
        $data['menu'] = $this->db->get('user_menu')->result_array();

        $data['title'] = 'Role Akses';
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/role-access', $data);
        $this->load->view('templates/footer', $data);
    }

    public function changeAccess()
    {
        $menu_id = $this->input->post('menuId');
        $rol_id = $this->input->post('rolId');

        $data = [
            'rol_id' => $rol_id,
            'menu_id' => $menu_id
        ];

        $result = $this->db->get_where('user_access_menu', $data);

        if ($result->num_rows() < 1) {
            $this->db->insert('user_access_menu', $data);
        } else {
            $this->db->delete('user_access_menu', $data);
        }

        $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert" >Akses Berhasil</div>');
    }

    public function dataPelatih()
    {
        $data['title'] = 'Data Pelatih';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['pelatih'] = $this->db->get('data_pelatih')->result_array();

        $this->form_validation->set_rules('nama_pelatih', 'Nama Pelatih', 'required|trim|', ['required' => 'Nama Wajib di isi']);
        $this->form_validation->set_rules('area_kerja', 'Area Kerja', 'required|trim', ['required' => 'Wajib di isi']);

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/data_pelatih', $data);
            $this->load->view('templates/footer', $data);
        } else { }
    }

    public function dataSiswa()
    {
        $data['title'] = 'Data Siswa';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['siswa'] = $this->db->get('data_siswa')->result_array();

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/data_siswa', $data);
            $this->load->view('templates/footer', $data);
        } else { }
    }

    public function orderJakarta()
    {
        $data['title'] = 'Order Jakarta';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['orderjakarta'] = $this->db->get('order_jakarta')->result_array();

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/order_jakarta', $data);
            $this->load->view('templates/footer', $data);
        } else { }
    }

    public function hapus($id)
    {
        $this->load->model('Order_model');
        $this->Order_model->hapusDataOrder($id);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert" >Data Berhasil di hapus</div>');
        redirect('admin/orderJakarta');
    }

    public function detail($id)
    {
        $data['title'] = 'Detail Order Jakarta';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['detailOrderJakarta'] = $this->db->get_where('order_jakarta', ['id' => $id])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/detail_order_jakarta', $data);
        $this->load->view('templates/footer', $data);
    }

    public function edit($id)
    {
        $data['title'] = 'Edit Order Jakarta';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['detailOrderJakarta'] = $this->db->get_where('order_jakarta', ['id' => $id])->row_array();

        $this->form_validation->set_rules('name', 'Nama Siswa', 'required|trim', ['required' => 'Form Wajib di isi']);
        $this->form_validation->set_rules('nama_orang_tua', 'Nama Orang tua', 'required|trim', ['required' => 'Form Wajib di isi']);
        $this->form_validation->set_rules('jenis_kelamin', 'Jenis kelamin', 'required|trim', ['required' => 'Form Wajib di isi']);
        $this->form_validation->set_rules('usia', 'Usia', 'required|trim', ['required' => 'Form Wajib di isi']);
        $this->form_validation->set_rules('nama_sekolah', 'nama_sekolah', 'required|trim', ['required' => 'Form Wajib di isi']);
        $this->form_validation->set_rules('telepon', 'telepon', 'required|trim|numeric', [
            'required' => 'Form Wajib di isi',
            'numeric' => 'Isi dengan Nomor'
        ]);
        $this->form_validation->set_rules('nama_kolam', 'nama_kolam', 'required|trim', ['required' => 'Form Wajib di isi']);
        $this->form_validation->set_rules('nama_kelas', 'nama_kelas', 'required|trim', ['required' => 'Form Wajib di isi']);
        $this->form_validation->set_rules('nama_pelatih', 'nama_pelatih', 'required|trim', ['required' => 'Form Wajib di isi']);
        $this->form_validation->set_rules('status_bayar', 'status_bayar', 'required|trim', ['required' => 'Form Wajib di isi']);


        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/edit_order_jakarta', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $data = [
                'nama_siswa' => ($this->input->post('name', true)),
                "nama_ortu" => ($this->input->post('nama_orang_tua', true)),
                "jenis_kelamin" => ($this->input->post('jenis_kelamin', true)),
                "usia" => ($this->input->post('usia', true)),
                "nama_sekolah" => ($this->input->post('nama_sekolah', true)),
                "telepon" => ($this->input->post('telepon', true)),
                "alamat-tinggal" => ($this->input->post('alamat', true)),
                "nama_kolam" => ($this->input->post('nama_kolam', true)),
                "nama_kelas" => ($this->input->post('nama_kelas', true)),
                "pelatih" => ($this->input->post('nama_pelatih', true)),
                "status" => ($this->input->post('status_bayar', true))
            ];

            $this->db->where('id', $id);
            $this->db->update('order_jakarta', $data);

            // $this->load->model('Order_model');
            // $this->Order_model->editDataOrder();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert" >Data Berhasil di edit</div>');
            redirect('admin/orderJakarta');
        }
    }
}
