<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <!-- Content Row -->
    <div class="row">
        <div class="col-lg-12">
            <?php if (validation_errors()) : ?>
                <div class="alert alert-danger" role="alert">
                    <?= validation_errors(); ?>
                </div>
            <?php endif; ?>
            <?= $this->session->flashdata('message'); ?>

            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Nama Siswa</th>
                        <th scope="col">Order Kelas</th>
                        <th scope="col">Tanggal Pesan</th>
                        <th scope="col">Status</th>
                        <th scope="col">Pelatih</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($orderjakarta as $oj) : ?>
                        <tr>
                            <th scope="row"><?= $i; ?></th>
                            <td><?= $oj['nama_siswa']; ?></td>
                            <td><?= $oj['nama_kelas']; ?></td>
                            <td><?= date('d F Y', $oj['date_created']); ?></td>
                            <td><?= $oj['status']; ?></td>
                            <td><?= $oj['pelatih']; ?></td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-primary btn-block dropdown-toggle" type="button" data-toggle="dropdown">
                                        pilih aksi
                                    </button>
                                    <div class="dropdown-menu">
                                        <a href="<?= base_url('admin/detail/') . $oj['id']; ?>" class="btn btn-warning dropdown-item "><i class="fas fa-info-circle"></i> Detail Siswa</a>
                                        <a href="<?= base_url('admin/edit/') . $oj['id']; ?>" class="btn btn-warning dropdown-item "><i class="fas fa-edit"></i> Edit</a>
                                        <a href="#" class="btn btn-warning dropdown-item "><i class="fas fa-share"></i> Kirim</a>
                                        <a href="#" class="btn btn-danger dropdown-item" data-toggle="modal" data-target="#hapusModal"><i class="fas fa-trash-alt"></i> Hapus</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>

        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- Logout Modal-->
<div class="modal fade" id="hapusModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Anda yakin mau menghapus data ini?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                <a class="btn btn-primary" href="<?= base_url('admin/hapus/') . $oj['id']; ?>">hapus</a>
            </div>
        </div>
    </div>
</div>