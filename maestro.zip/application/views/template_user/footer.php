 <!-- Footer -->
 <footer class="border-top p-5">
     <div class="container">
         <div class="row justify-content-between">
             <div class="col-1">
                 <a href="">
                 </a>
             </div>
             <div class="col-4 text-right">
                 <a href="">
                     <img src="<?= base_url('assets/') ?>img/social/fb.png">
                 </a>
                 <a href="">
                     <img src="<?= base_url('assets/') ?>img/social/twitter.png">
                 </a>
                 <a href="">
                     <img src="<?= base_url('assets/') ?>img/social/ig.png">
                 </a>
             </div>
         </div>
         <div class="row mt-3 justify-content-between">
             <div class="col-5">
                 <p>All Rights Reserved by Maestro Swim <i class="fas fa-copyright"></i> Copyright <?= date('Y'); ?></p>
             </div>
             <div class="col-6">
                 <nav class="nav justify-content-end text-uppercase">
                     <a class="nav-link active" href="#">Jobs</a>
                     <a class="nav-link" href="#">Developer</a>
                     <a class="nav-link" href="#">Terms</a>
                     <a class="nav-link pr-0" href="#">Privacy Policy</a>
                 </nav>
             </div>
         </div>
     </div>
 </footer>
 <!-- Akhir Footer -->


 <!-- Optional JavaScript -->
 <!-- Bootstrap core JavaScript-->
 <script src="<?= base_url('assets/'); ?>vendor/jquery/jquery.min.js"></script>
 <script src="<?= base_url('assets/'); ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

 <!-- Core plugin JavaScript-->
 <script src="<?= base_url('assets/'); ?>vendor/jquery-easing/jquery.easing.min.js"></script>

 <!-- Custom scripts for all pages-->
 <script src="<?= base_url('assets/'); ?>js/sb-admin-2.min.js"></script>
 </body>

 </html>