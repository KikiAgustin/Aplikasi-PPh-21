      <!-- Content Wrapper -->
      <div id="content-wrapper" class="d-flex flex-column">

          <!-- Main Content -->
          <div id="content">

              <!-- Topbar -->
              <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                  <!-- Sidebar Toggle (Topbar) -->
                  <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                      <i class="fa fa-bars"></i>
                  </button>


                  <!-- Topbar Navbar -->
                  <ul class="navbar-nav ml-auto">

                      <!-- Dropdown - Messages -->
                      <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                          <form class="form-inline mr-auto w-100 navbar-search">
                              <div class="input-group">
                                  <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                                  <div class="input-group-append">
                                      <button class="btn btn-primary" type="button">
                                          <i class="fas fa-search fa-sm"></i>
                                      </button>
                                  </div>
                              </div>
                          </form>
                      </div>
                      </li>

                      <div class="topbar-divider d-none d-sm-block"></div>

                      <!-- Nav Item - User Information -->
                      <li class="nav-item dropdown no-arrow">
                          <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?= $user['name']; ?></span>
                              <img class="img-profile rounded-circle" src="<?= base_url('assets/img/profile/') . $user['image']; ?>">
                          </a>
                          <!-- Dropdown - User Information -->
                          <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                              <a class="dropdown-item" href="#">
                                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                  Profile
                              </a>
                              <div class="dropdown-divider"></div>
                              <a class="dropdown-item" href="<?= base_url('auth/logout'); ?>" data-toggle="modal" data-target="#logoutModal">
                                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                  Keluar
                              </a>
                          </div>
                      </li>

                  </ul>

              </nav>
              <!-- End of Topbar -->
              <!-- Begin Page Content -->
              <div class="container-fluid">
                  <!-- Begin Page Content -->
                  <div class="container-fluid">

                      <!-- Page Heading -->
                      <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>


                      <div class="row">
                          <div class="col-lg-8">

                              <?= form_open_multipart('user/edit'); ?>

                              <div class="form-group row">
                                  <label for="name" class="col-sm-3 col-form-label">Nama Lengkap</label>
                                  <div class="col-sm-9">
                                      <input type="text" class="form-control" id="name" name="name">
                                      <?= form_error('name', '<small class="text-danger pl-3">', '</small>'); ?>
                                  </div>
                              </div>

                              <div class="form-group row">
                                  <div class="col-sm-3">Gambar</div>
                                  <div class="col-sm-9">
                                      <div class="row">
                                          <div class="col-sm-3">
                                              <img src="<?= base_url('assets/img/profile/') . $user['image']; ?>" class="img-thumbnail">
                                          </div>
                                          <div class="col-sm-9">
                                              <div class="custom-file">
                                                  <input type="file" class="custom-file-input" id="image" name="image">
                                                  <label class="custom-file-label" for="image">Tambah File</label>
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                              </div>

                              <div class="form-group row">
                                  <label for="jk" class="col-sm-3 col-form-label">Jenis Kelamin</label>
                                  <div class="col-sm-9">
                                      <select name="jk" id="jk" class="form-control">
                                          <option>Pilih Jenis Kelamin</option>
                                          <option value="Laki-Laki">Laki-Laki</option>
                                          <option value="Perempuan">Perempuan</option>
                                      </select>
                                      <?= form_error('jk', '<small class="text-danger pl-3">', '</small>'); ?>
                                  </div>
                              </div>

                              <div class="form-group row">
                                  <label for="area" class="col-sm-3 col-form-label">Area kerja</label>
                                  <div class="col-sm-9">
                                      <input type="text" class="form-control" id="area" name="area">
                                      <?= form_error('area', '<small class="text-danger pl-3">', '</small>'); ?>
                                  </div>
                              </div>

                              <div class="form-group row">
                                  <label for="gabung" class="col-sm-3 col-form-label">Mulai Gabung</label>
                                  <div class="col-sm-9">
                                      <input type="text" class="form-control" id="gabung" name="gabung">
                                      <?= form_error('gabung', '<small class="text-danger pl-3">', '</small>'); ?>
                                  </div>
                              </div>


                              <div class="form-group row">
                                  <label for="kata" class="col-sm-3 col-form-label">Kata Mutiara</label>
                                  <div class="col-sm-9">
                                      <textarea class="form-control" id="kata" name="kata" rows="3"></textarea>
                                      <?= form_error('kata', '<small class="text-danger pl-3">', '</small>'); ?>
                                  </div>
                              </div>

                              <div class="row form-group justify-content-end">
                                  <div class="col-sm-9">
                                      <button type="submit" name="submit" class="btn btn-primary">Registrasi</button>
                                  </div>
                              </div>

                              </form>
                          </div>
                      </div>

                  </div>
                  <!-- /.container-fluid -->

              </div>
              <!-- End of Main Content -->