<script src="<?= base_url('app-assets/'); ?>js/vendors.min.js" type="text/javascript"></script>
<script src="<?= base_url('app-assets/'); ?>js/plugins.js" type="text/javascript"></script>
<script src="<?= base_url('app-assets/'); ?>js/custom/custom-script.js" type="text/javascript"></script>
</body>

</html>