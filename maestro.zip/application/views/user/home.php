<!-- Jumbotroon -->
<div class="jumbotron homeuser jumbotron-fluid">
    <div class="container">
        <h3>Selamat datang <?= $user['name']; ?></h3>
        <p class="lead">Tempat terbaik untuk untuk solusi belajar renang</p>
        <p class="lead">Berikut adalah produk-produk kami</p>
    </div>
</div>
<!-- Akhir Jumbo troon -->

<!-- catalog kelas -->
<section class="designer">
    <h5 class="container">

        <div class="row">
            <div class="col mb-4">
                <h3>Jabodetabek</h3>
            </div>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <div class="card" style="width: 18rem;">
                        <img src="<?= base_url('assets/img/catalog/1.jpg'); ?>" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title">Private</h5>
                            <a href="<?= base_url('user/detailCatalogPrivateJakarta'); ?>" class="btn btn-primary">Detail Kelas</a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 mb-4">
                    <div class="card" style="width: 18rem;">
                        <img src="<?= base_url('assets/img/catalog/2.jpg'); ?>" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title">Kelas</h5>
                            <a href="<?= base_url('user/detailCatalogKelasJakarta'); ?>" class="btn btn-primary">Detail Kelas</a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 mb-4">
                    <div class="card" style="width: 18rem;">
                        <img src="<?= base_url('assets/img/catalog/jakarta3.jpg'); ?>" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title">Terapi</h5>
                            <a href="<?= base_url('user/detailCatalogTerapiJakarta'); ?>" class="btn btn-primary">Detail Kelas</a>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div class="row">
            <div class="col mb-4">
                <h3>Bandung</h3>
            </div>
        </div>

        <div class="container">
            <div class="row">
                <?php foreach ($catalogbandung as $cb) : ?>
                    <div class="col-lg-4 mb-4">
                        <div class="card" style="width: 18rem;">
                            <img src="<?= base_url('assets/img/catalog/') . $cb['image']; ?>" class="card-img-top">
                            <div class="card-body">
                                <h5 class="card-title"><?= $cb['nama_kelas']; ?></h5>
                                <a href="<?= base_url('user/detailcatalogbandung/') . $cb['id']; ?>" class="btn btn-primary">Detail Kelas</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>

            </div>
        </div>

</section>
<!-- Akhir catalog kelas -->