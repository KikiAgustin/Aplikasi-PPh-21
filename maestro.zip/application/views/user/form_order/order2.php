<!-- Form Order -->
<section class="designer formorder">
    <div class="container">
        <nav>
            <ol class="breadcrumb bg-transparent pl-0 cart-breadcrumb ">
                <li class="breadcrumb-item mt-2"><a href="<?= base_url('user/home') ?>">Home</a></li>
                <li class="breadcrumb-item  mt-2 active" aria-current="page"><?= $title; ?></li>
            </ol>
        </nav>
        <div class="row">
            <div class="col mb-4">
                <h3>Form Order Swim Maestro</h3>
            </div>
        </div>

        <form action="" method="post">

            <div class="row">
                <h4>Identitas Siswa 1</h4>
                <div class="col-lg-8">
                    <?= form_open_multipart('user/edit'); ?>
                    <div class="form-group row">
                        <label for="name_siswa" class="col-sm-3 col-form-label">Nama Siswa </label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="name_siswa" name="name_siswa" value="<?= set_value('name_siswa'); ?>">
                            <?= form_error('name_siswa', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="nama_ortu" class="col-sm-3 col-form-label">Nama Orang Tua</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="nama_ortu" name="nama_ortu" value="<?= set_value('nama_ortu'); ?>">
                            <?= form_error('nama_ortu', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="jk" class="col-sm-3 col-form-label">Jenis Kelamin</label>
                        <div class="col-sm-9">
                            <select name="jk" id="jk" class="form-control">
                                <option>Pilih Jenis Kelamin</option>
                                <option value="Laki-Laki">Laki-Laki</option>
                                <option value="Perempuan">Perempuan</option>
                            </select>
                            <?= form_error('jk', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="usia" class="col-sm-3 col-form-label">Usia</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="usia" name="usia" value="<?= set_value('usia'); ?>">
                            <?= form_error('usia', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="nama_sekolah" class="col-sm-3 col-form-label">Nama Sekolah</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="nama_sekolah" name="nama_sekolah" value="<?= set_value('nama_sekolah'); ?>">
                            <?= form_error('nama_sekolah', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="telepon" class="col-sm-3 col-form-label">Telepon</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="telepon" name="telepon" value="<?= set_value('telepon'); ?>">
                            <?= form_error('telepon', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="alamat_tinggal" class="col-sm-3 col-form-label">Alamat Tinggal</label>
                        <div class="col-sm-9">
                            <textarea type="text" class="form-control" id="alamat_tinggal" name="alamat_tinggal" value="<?= set_value('alamat_tinggal'); ?>"></textarea>
                            <?= form_error('alamat_tinggal', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="kelas" class="col-sm-3 col-form-label">Paket Yang di Pilih</label>
                        <div class="col-sm-9">
                            <select name="kelas" id="kelas" class="form-control">
                                <option>Pilih</option>
                                <option value="2 Siswa 4 Pertemuan">2 Siswa 4 Pertemuan</option>
                                <option value="2 Siswa 8 Pertemuan">2 Siswa 8 Pertemuan</option>
                            </select>
                            <?= form_error('kelas', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="kolam" class="col-sm-3 col-form-label">Kolam Tempat Latihan</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="kolam" name="kolam" value="<?= set_value('kolam'); ?>">
                            <?= form_error('kolam', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Identitas Siswa 2 -->

            <div class="row">
                <h4>Identitas Siswa 2</h4>
                <div class="col-lg-8">
                    <?= form_open_multipart('user/edit'); ?>
                    <div class="form-group row">
                        <label for="name_siswa" class="col-sm-3 col-form-label">Nama Siswa </label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="name_siswa" name="name_siswa1" value="<?= set_value('name_siswa1'); ?>">
                            <?= form_error('name_siswa', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="nama_ortu" class="col-sm-3 col-form-label">Nama Orang Tua</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="nama_ortu" name="nama_ortu1" value="<?= set_value('nama_ortu1'); ?>">
                            <?= form_error('nama_ortu', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="jk" class="col-sm-3 col-form-label">Jenis Kelamin</label>
                        <div class="col-sm-9">
                            <select name="jk1" id="jk" class="form-control">
                                <option>Pilih Jenis Kelamin</option>
                                <option value="Laki-Laki">Laki-Laki</option>
                                <option value="Perempuan">Perempuan</option>
                            </select>
                            <?= form_error('jk', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="usia" class="col-sm-3 col-form-label">Usia</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="usia" name="usia1" value="<?= set_value('usia1'); ?>">
                            <?= form_error('usia', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="nama_sekolah" class="col-sm-3 col-form-label">Nama Sekolah</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="nama_sekolah" name="nama_sekolah1" value="<?= set_value('nama_sekolah1'); ?>">
                            <?= form_error('nama_sekolah', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="telepon" class="col-sm-3 col-form-label">Telepon</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="telepon" name="telepon1" value="<?= set_value('telepon1'); ?>">
                            <?= form_error('telepon', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="alamat_tinggal" class="col-sm-3 col-form-label">Alamat Tinggal</label>
                        <div class="col-sm-9">
                            <textarea type="text" class="form-control" id="alamat_tinggal" name="alamat_tinggal1" value="<?= set_value('alamat_tinggal1'); ?>"></textarea>
                            <?= form_error('alamat_tinggal', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="kelas" class="col-sm-3 col-form-label">Paket Yang di Pilih</label>
                        <div class="col-sm-9">
                            <select name="kelas1" id="kelas" class="form-control">
                                <option>Pilih</option>
                                <option value="2 Siswa 4 Pertemuan">2 Siswa 4 Pertemuan</option>
                                <option value="2 Siswa 8 Pertemuan">2 Siswa 8 Pertemuan</option>
                            </select>
                            <?= form_error('kelas', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="kolam" class="col-sm-3 col-form-label">Kolam Tempat Latihan</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="kolam" name="kolam1" value="<?= set_value('kolam1'); ?>">
                            <?= form_error('kolam', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>
                </div>
            </div>


            <div class="row form-group justify-content-end">
                <div class="col-sm-9">
                    <button type="submit" name="submit" class="btn btn-primary">Order Sekarang</button>
                </div>
            </div>


        </form>


</section>
<!-- Akhir catalog kelas -->