      <div class="container">
          <nav>
              <ol class="breadcrumb bg-transparent pl-0 cart-breadcrumb ">
                  <li class="breadcrumb-item mt-2"><a href="<?= base_url('user/home') ?>">Home</a></li>
                  <li class="breadcrumb-item  mt-2 active" aria-current="page"><?= $title; ?></li>
              </ol>
          </nav>


          <!-- Content Wrapper -->
          <div id="content-wrapper" class="d-flex flex-column">

              <!-- Main Content -->
              <div id="content">

                  <!-- Begin Page Content -->
                  <div class="container-fluid">
                      <!-- Begin Page Content -->
                      <div class="container-fluid">

                          <!-- Page Heading -->
                          <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>


                          <div class="row">
                              <div class="col-lg-8">

                                  <?= form_open_multipart('user/edit'); ?>

                                  <div class="form-group row">
                                      <label for="email" class="col-sm-3 col-form-label">Email</label>
                                      <div class="col-sm-9">
                                          <input type="text" class="form-control" id="email" name="email" value="<?= $user['email']; ?>" readonly>
                                      </div>
                                  </div>

                                  <div class="form-group row">
                                      <label for="name" class="col-sm-3 col-form-label">Nama Lengkap</label>
                                      <div class="col-sm-9">
                                          <input type="text" class="form-control" id="name" name="name" value="<?= $user['name']; ?>">
                                          <?= form_error('name', '<small class="text-danger pl-3">', '</small>'); ?>
                                      </div>
                                  </div>

                                  <div class="form-group row">
                                      <div class="col-sm-3">Gambar</div>
                                      <div class="col-sm-9">
                                          <div class="row">
                                              <div class="col-sm-3">
                                                  <img src="<?= base_url('assets/img/profile/') . $user['image']; ?>" class="img-thumbnail">
                                              </div>
                                              <div class="col-sm-9">
                                                  <div class="custom-file">
                                                      <input type="file" class="custom-file-input" id="image" name="image">
                                                      <label class="custom-file-label" for="image">Tambah File</label>
                                                  </div>
                                              </div>
                                          </div>
                                      </div>
                                  </div>

                                  <div class="row form-group justify-content-end">
                                      <div class="col-sm-9">
                                          <button type="submit" name="submit" class="btn btn-primary">Edit</button>
                                      </div>
                                  </div>

                                  </form>
                              </div>
                          </div>

                      </div>
                      <!-- /.container-fluid -->

                  </div>
                  <!-- End of Main Content -->
              </div>