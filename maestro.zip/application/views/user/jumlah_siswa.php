<!-- Form Order -->
<section class="designer formorder">
    <div class="container">
        <nav>
            <ol class="breadcrumb bg-transparent pl-0 cart-breadcrumb ">
                <li class="breadcrumb-item mt-2"><a href="<?= base_url('user/home') ?>">Home</a></li>
                <li class="breadcrumb-item  mt-2 active" aria-current="page"><?= $title; ?></li>
            </ol>
        </nav>
        <div class="row">
            <div class="col mb-4">
                <h3>Pilih Paket kelas</h3>
            </div>
        </div>

        <form action="" method="post">

            <div class="row">
                <div class="col-lg-8">
                    <?= form_open_multipart('user/edit'); ?>

                    <div class="form-group row">
                        <label for="jumlah_siswa" class="col-sm-3 col-form-label">Pilih Paket</label>
                        <div class="col-sm-9">
                            <select name="jumlah_siswa" id="jumlah_siswa" class="form-control">
                                <option value="1">Private 1 Siswa</option>
                                <option value="2">private 2 Siswa</option>
                                <option value="3">Private 3 Siswa</option>
                                <option value="4">Private 4 Siswa</option>
                            </select>
                            <?= form_error('jumlah_siswa', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="row form-group justify-content-end">
                        <div class="col-sm-9">
                            <button type="submit" name="submit" class="btn btn-primary">Order Sekarang</button>
                        </div>
                    </div>

                </div>
            </div>
        </form>


</section>
<!-- Akhir catalog kelas -->