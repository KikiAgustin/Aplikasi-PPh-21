<!-- catalog kelas -->
<section>
    <div class="container ">
        <nav>
            <ol class="breadcrumb bg-transparent pl-0 cart-breadcrumb ">
                <li class="breadcrumb-item mt-2"><a href="<?= base_url('user/home') ?>">Home</a></li>
                <li class="breadcrumb-item  mt-2 active" aria-current="page"><?= $title; ?></li>
            </ol>
        </nav>

        <div class="row">
            <div class="col-lg-4">
                <figure class="figure">
                    <img src="<?= base_url('assets/img/catalog/1.jpg'); ?>" class="figure-img img-fluid">
                </figure>
            </div>
            <div class="col col-lg-8">
                <div class="jumbotron">
                    <h2>Private</h2>
                    <hr class="my-4">
                    <h4>Detail Harga</h4>
                    <p>Registrasi Rp. <?= number_format($detailcatalog['registrasi'], 0, ',', '.');  ?></p>
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th scope="col">Pertemuan</th>
                                <th scope="col">Jumlah Siswa</th>
                                <th scope="col">Harga</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th scope="row">4 Kali</th>
                                <td>1</td>
                                <td>700.000 / Orang</td>
                            </tr>
                            <tr>
                                <th scope="row">8 Kali</th>
                                <td>1</td>
                                <td>1.300.000 / Orang</td>
                            </tr>
                            <tr>
                                <th scope="row">4 Kali</th>
                                <td>2</td>
                                <td>500.000 / Orang</td>
                            </tr>
                            <tr>
                                <th scope="row">8 Kali</th>
                                <td>2</td>
                                <td>900.000 / Orang</td>
                            </tr>
                            <tr>
                                <th scope="row">4 Kali</th>
                                <td>3 sd 4</td>
                                <td>400.000 / Orang</td>
                            </tr>
                            <tr>
                                <th scope="row">8 Kali</th>
                                <td>3 sd 4</td>
                                <td>700.000 / Orang</td>
                            </tr>
                        </tbody>
                    </table>
                    <p>Note : Harga belum termasuk dengan tiket kolam</p>

                    <hr class="my-4">
                    <a href="<?= base_url('user/home'); ?>" class="btn btn-warning">Kembali</a>
                    <a href="<?= base_url('user/jumlahSiswa'); ?>" class="btn btn-primary">Beli kelas</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Akhir catalog kelas -->