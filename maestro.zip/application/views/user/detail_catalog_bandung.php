<!-- catalog kelas -->
<section>
    <div class="container ">
        <nav>
            <ol class="breadcrumb bg-transparent pl-0 cart-breadcrumb ">
                <li class="breadcrumb-item mt-2"><a href="<?= base_url('user/home') ?>">Home</a></li>
                <li class="breadcrumb-item  mt-2 active" aria-current="page"><?= $title; ?></li>
            </ol>
        </nav>

        <div class="row">
            <div class="col-lg-4">
                <figure class="figure">
                    <img src="<?= base_url('assets/img/catalog/') . $detailcatalogbandung['image']; ?>" class="figure-img img-fluid">
                </figure>
            </div>
            <div class="col col-lg-8">
                <div class="jumbotron">
                    <h2><?= $detailcatalogbandung['nama_kelas']; ?></h2>
                    <hr class="my-4">
                    <p><?= $detailcatalogbandung['keterangan']; ?></p>
                    <p>Registrasi <?= $detailcatalogbandung['registrasi']; ?></p>
                    <h4>Biaya Latihan</h4>
                    <p>4 kali pertemuan <?= $detailcatalogbandung['bandung4'] ?></p>
                    <p>8 kali pertemuan <?= $detailcatalogbandung['bandung8'] ?></p>
                    <hr class="my-4">
                    <a href="<?= base_url('user/home'); ?>" class="btn btn-warning">Kembali</a>
                    <a href="<?= base_url('user/orderbandung/') . $detailcatalogbandung['id']; ?>" class="btn btn-primary">Beli kelas ini</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Akhir catalog kelas -->