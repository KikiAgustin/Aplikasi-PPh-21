<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/'); ?>css/sb-admin-2.min.css">

    <!-- Font awesome -->
    <link href="<?= base_url('assets/'); ?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Lora:400,700|Montserrat:200,400,600&display=swap" rel="stylesheet">

    <!-- My CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>">

    <title><?= $title; ?></title>
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <div class="container">
            <a class="navbar-brand" href="<?= base_url('user/home'); ?>">Maestro Swim</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse " id="navbarNavAltMarkup">
                <div class="navbar-nav ml-auto ">
                    <a class="nav-item nav-link active" href="<?= base_url('user/home'); ?>">Home <span class="sr-only">(current)</span></a>
                    <a class="nav-item nav-link" href="<?= base_url('user'); ?>">My Profil</a>
                    <a class="nav-item nav-link" href="<?= base_url('user/datapelatih'); ?>">Tim Pelatih</a>
                </div>
            </div>
        </div>
    </nav>
    <!-- Akhir navbar -->

    <!-- Brands -->
    <section class="brands designer">
        <div class="container">

            <div class="row">
                <div class="col mb-2">
                    <h3>Sponsor</h3>
                </div>
            </div>
            <div class="row p-5 text-center">
                <div class="col-md">
                    <img src="<?= base_url('assets/'); ?>img/brand/cc.png" class="img-fluid">
                </div>
                <div class="col-md">
                    <img src="<?= base_url('assets/'); ?>img/brand/nike.png" class="img-fluid">
                </div>
                <div class="col-md">
                    <img src="<?= base_url('assets/'); ?>img/brand/pnb.png" class="img-fluid">
                </div>
                <div class="col-md">
                    <img src="<?= base_url('assets/'); ?>img/brand/uniqlo.png" class="img-fluid">
                </div>
            </div>
        </div>
    </section>
    <!-- Akhir Brands -->

    <!-- Designer -->
    <section class="designer mt-4">
        <div class="container">
            <div class="row mb-3">
                <div class="col mb-2">
                    <h3>Coach Maestro Swim</h3>
                </div>
            </div>

            <div class="row">
                <?php $i = 1 ?>
                <?php foreach ($pelatih as $p) : ?>
                    <div class="col col-lg-3">
                        <div class="card">
                            <img src="<?= base_url('assets/img/profil_pelatih/') . $p['image']; ?>" class="card-img-top" alt="...">
                            <div class="card-body">
                                <h5 class="card-title"><?= $p['nama_pelatih']; ?></h5>
                                <a href="#" class="btn btn-primary">Detail pelatih</a>
                            </div>
                        </div>
                    </div>
                    <?php $i++; ?>
                <?php endforeach; ?>
            </div>

        </div>
    </section>
    <!-- Akhir Designer -->


    <!-- Footer -->
    <footer class="border-top p-5">
        <div class="container">
            <div class="row justify-content-between">
                <div class="col-1">
                    <a href="">
                        <img src="<?= base_url('assets/') ?>img/logo_smalll.png">
                    </a>
                </div>
                <div class="col-4 text-right">
                    <a href="">
                        <img src="<?= base_url('assets/') ?>img/social/fb.png">
                    </a>
                    <a href="">
                        <img src="<?= base_url('assets/') ?>img/social/twitter.png">
                    </a>
                    <a href="">
                        <img src="<?= base_url('assets/') ?>img/social/ig.png">
                    </a>
                </div>
            </div>
            <div class="row mt-3 justify-content-between">
                <div class="col-5">
                    <p>All Rights Reserved by Maestro Swim <i class="fas fa-copyright"></i> Copyright <?= date('Y'); ?></p>
                </div>
                <div class="col-6">
                    <nav class="nav justify-content-end text-uppercase">
                        <a class="nav-link active" href="#">Jobs</a>
                        <a class="nav-link" href="#">Developer</a>
                        <a class="nav-link" href="#">Terms</a>
                        <a class="nav-link pr-0" href="#">Privacy Policy</a>
                    </nav>
                </div>
            </div>
        </div>
    </footer>
    <!-- Akhir Footer -->






    <!-- Bootstrap core JavaScript-->
    <script src="<?= base_url('assets/'); ?>vendor/jquery/jquery.min.js"></script>
    <script src="<?= base_url('assets/'); ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?= base_url('assets/'); ?>vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?= base_url('assets/'); ?>js/sb-admin-2.min.js"></script>
</body>

</html>