<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/'); ?>css/sb-admin-2.min.css">

    <!-- Font awesome -->
    <link href="<?= base_url('assets/'); ?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Lora:400,700|Montserrat:200,400,600&display=swap" rel="stylesheet">

    <!-- My CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>">

    <title><?= $title; ?></title>
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="<?= base_url('user'); ?>">
                <img src="<?= base_url('assets/'); ?>img/logo_smalll.png" alt="Hefa Store">
                Maestro Swim Academy
            </a>
        </div>
    </nav>
    <!-- Akhir Navbar -->

    <!-- Breadcrumbs -->
    <div class="container mt-5">
        <nav>
            <ol class="breadcrumb bg-transparent pl-0">
                <li class="breadcrumb-item"><a href="<?= base_url('user'); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?= base_url('user/datapelatih'); ?>">Pelatih</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?= $title; ?></li>
            </ol>
        </nav>
    </div>

    <!-- Single Product -->
    <section class="single-product">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <figure class="figure">
                        <img src="<?= base_url('assets') ?>../img/single/3.png" class="figure-img img-fluid">
                    </figure>
                </div>

                <div class="col-lg-4">
                    <h3>Kiki Agustin</h3>
                    <p class="text-muted">Laki-Laki</p>
                    <p class="text-muted">Bandung</p>
                    <p class="text-muted">Sejak Agustus 2019 Bergabung dengan Maestro</p>
                    <p class="text-muted">Belajar renang adalah cara terbaik untuk bisa menghindari dari ancaman air</p>
                    <p class="text-muted">Sudah 30 Siswa sampai saat ini</p>
                    <button class="btn btn-primary mb-5" data-toggle="modal" data-target="#exampleModal">Review Pelatih ini</button>

                    <div class="designed-by">
                        <a href="">
                            <h5>Maestro Swim</h5>
                        </a>
                        <div class="row">
                            <div class="col-2">
                                <img src="<?= base_url('assets') ?>../img/single/2.png">
                            </div>
                            <div class="col ml-1">
                                <h4><?= $user['name']; ?></h4>
                                <p> Member Sejak <?= date('d F Y', $user['date_created']); ?></span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Product Description & Review -->
    <section class="product-description p-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-9">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="description-tab" data-toggle="tab" href="#description" role="tab" aria-controls="description" aria-selected="true">Data Siswa</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="review-tab" data-toggle="tab" href="#review" role="tab" aria-controls="review" aria-selected="false">Reviews (20)</a>
                        </li>
                    </ul>
                    <div class="tab-content p-3" id="myTabContent">
                        <div class="tab-pane fade show active product-review" id="description" role="tabpanel" aria-labelledby="description-tab">
                            <!-- Content Row -->
                            <div class="row">
                                <div class="col-lg-8">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th scope="col">No</th>
                                                <th scope="col">Nama Pelatih</th>
                                                <th scope="col">Jenis kelamin</th>
                                                <th scope="col">Area Kerja</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td>kiki Agustin</td>
                                                <td>Laki-laki</td>
                                                <td>Bandung</td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade product-review" id="review" role="tabpanel" aria-labelledby="review-tab">
                            <div class="row">
                                <div class="col-1 d-none d-md-block">
                                    <img src="<?= base_url('assets') ?>../img/single/review/3.png">
                                </div>
                                <div class="col">
                                    <h5>Joe Mackenzie</h5>
                                    <p>Produknya bagus dan bahannya juga rapih cocok untuk kulit</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-1 d-none d-md-block">
                                    <img src="<?= base_url('assets') ?>../img/single/review/4.png">
                                </div>
                                <div class="col">
                                    <h5>Jessica</h5>
                                    <p>Produknya bagus dan bahannya juga rapih cocok untuk kulit</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-1 d-none d-md-block">
                                    <img src="<?= base_url('assets') ?>../img/single/review/5.png">
                                </div>
                                <div class="col">
                                    <h5>Sen Swith</h5>
                                    <p>Produknya bagus dan bahannya juga rapih cocok untuk kulit</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-1 d-none d-md-block">
                                    <img src="<?= base_url('assets') ?>../img/single/review/6.png">
                                </div>
                                <div class="col">
                                    <h5>Keane</h5>
                                    <p>Produknya bagus dan bahannya juga rapih cocok untuk kulit</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-1 d-none d-md-block">
                                    <img src="<?= base_url('assets') ?>../img/single/review/7.png">
                                </div>
                                <div class="col">
                                    <h5>Joe Mackenzie</h5>
                                    <p>Produknya bagus dan bahannya juga rapih cocok untuk kulit</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-1 d-none d-md-block">
                                    <img src="<?= base_url('assets') ?>../img/single/review/8.png">
                                </div>
                                <div class="col">
                                    <h5>Amelia </h5>
                                    <p>Produknya bagus dan bahannya juga rapih cocok untuk kulit</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Akhir Product Description & Review -->


    <!-- Footer -->
    <footer class="border-top p-5">
        <div class="container">
            <div class="row justify-content-between">
                <div class="col-1">
                    <a href="">
                        <img src="<?= base_url('assets/') ?>img/logo_smalll.png">
                    </a>
                </div>
                <div class="col-4 text-right">
                    <a href="">
                        <img src="<?= base_url('assets/') ?>img/social/fb.png">
                    </a>
                    <a href="">
                        <img src="<?= base_url('assets/') ?>img/social/twitter.png">
                    </a>
                    <a href="">
                        <img src="<?= base_url('assets/') ?>img/social/ig.png">
                    </a>
                </div>
            </div>
            <div class="row mt-3 justify-content-between">
                <div class="col-5">
                    <p>All Rights Reserved by Maestro Swim <i class="fas fa-copyright"></i> Copyright <?= date('Y'); ?></p>
                </div>
                <div class="col-6">
                    <nav class="nav justify-content-end text-uppercase">
                        <a class="nav-link active" href="#">Jobs</a>
                        <a class="nav-link" href="#">Developer</a>
                        <a class="nav-link" href="#">Terms</a>
                        <a class="nav-link pr-0" href="#">Privacy Policy</a>
                    </nav>
                </div>
            </div>
        </div>
    </footer>
    <!-- Akhir Footer -->

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Review Pelatih ini</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?= base_url('menu/submenu'); ?>" method="post">
                    <div class="modal-body">
                        <div class="form-group">
                            <textarea class="form-control" id="review" name="review" rows="3" placeholder="Tulis di sini"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Review</button>
                    </div>
                </form>
            </div>
        </div>
    </div>






    <!-- Bootstrap core JavaScript-->
    <script src="<?= base_url('assets/'); ?>vendor/jquery/jquery.min.js"></script>
    <script src="<?= base_url('assets/'); ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?= base_url('assets/'); ?>vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?= base_url('assets/'); ?>js/sb-admin-2.min.js"></script>
</body>

</html>