<!-- catalog kelas -->
<section>
    <div class="container ">
        <nav>
            <ol class="breadcrumb bg-transparent pl-0 cart-breadcrumb ">
                <li class="breadcrumb-item mt-2"><a href="<?= base_url('user/home') ?>">Home</a></li>
                <li class="breadcrumb-item  mt-2 active" aria-current="page"><?= $title; ?></li>
            </ol>
        </nav>

        <div class="row">
            <div class="col-lg-4">
                <figure class="figure">
                    <img src="<?= base_url('assets/img/profile/') . $user['image']; ?>" class="figure-img img-fluid">
                </figure>
                <a class="btn btn-primary mb-3" href="<?= base_url('user/edit'); ?>">Edit Profile</a>
            </div>
            <div class="col col-lg-8">
                <div class="jumbotron">
                    <h3><?= $user['name']; ?></h3>
                    <br>
                    <p>Member sejak <?= date('d F Y', $user['date_created']); ?></p>
                </div>
                <a class="btn btn-primary mb-3" href="<?= base_url('user/changePassword'); ?>">Ganti Password</a>
                <a class="btn btn-primary mb-3" href="<?= base_url('auth/logout'); ?>">Keluar</a>
            </div>
        </div>
    </div>
</section>
<!-- Akhir catalog kelas -->