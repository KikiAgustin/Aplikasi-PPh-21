<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/'); ?>css/sb-admin-2.min.css">

    <!-- Font awesome -->
    <link href="<?= base_url('assets/'); ?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Lora:400,700|Montserrat:200,400,600&display=swap" rel="stylesheet">

    <!-- My CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>">

    <title><?= $title; ?></title>
</head>

<body>

    <!-- Modal -->
    <div class="">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <img src="<?= base_url('assets/') ?>img/cart/sukses_checkout.png" class="mb-5">
                    <h3>Order Anda Berhasil</h3>
                    <p>Silahkan lakukan pemabayaran ke No Rek 1300016982830 AN MAESTRO BISA, dan konfirmasi ke admin apabila sudah melakukan pembayaran</p>
                    <p>Terimakasih Sudah menggunakan jasa kami</p>
                    <a href="<?= base_url('user/home'); ?>" class="btn btn-warning text-white">Home</a>
                </div>
            </div>
        </div>
    </div>


    <!-- Optional JavaScript -->
    <!-- Bootstrap core JavaScript-->
    <script src="<?= base_url('assets/'); ?>vendor/jquery/jquery.min.js"></script>
    <script src="<?= base_url('assets/'); ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?= base_url('assets/'); ?>vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?= base_url('assets/'); ?>js/sb-admin-2.min.js"></script>
</body>

</html>