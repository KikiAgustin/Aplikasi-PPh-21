/*
 * Form Layouts - Form
 */

$(document).ready(function () {
    $('.datepicker').datepicker({
        format: 'yyyy-mm-dd'
    });
})